VoiceOver Fix - cara build:
1. Ekstrak zip ini. Upload ISI-nya (bukan foldernya) ke repo GitHub, sehingga
   settings.gradle.kts dan folder app berada di halaman utama repo.
2. Pastikan folder .github/workflows/build.yml ikut terupload.
3. Buka tab Actions, tunggu build selesai, download artifact VoiceOverFix-apk.
