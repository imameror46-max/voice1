package com.voiceoverfix

import android.content.ContentValues
import android.content.Context
import android.media.*
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.*
import com.whispercpp.whisper.WhisperContext
import java.io.File
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder

class Pcm(val data: ShortArray, val rate: Int)
class Seg(val start: Double, val end: Double, val text: String)
class Hit(val script: String, val heard: String, val score: Double, val start: Double, val end: Double)

fun decode(ctx: Context, uri: Uri): Pcm {
    val ex = MediaExtractor(); ex.setDataSource(ctx, uri, null)
    val idx = (0 until ex.trackCount).first { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)!!.startsWith("audio/") }
    ex.selectTrack(idx)
    val fmt = ex.getTrackFormat(idx)
    val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
    codec.configure(fmt, null, null, 0); codec.start()
    var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE); var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
    val out = ByteArrayOutputStream(); val info = MediaCodec.BufferInfo()
    var inDone = false; var outDone = false
    while (!outDone) {
        if (!inDone) {
            val i = codec.dequeueInputBuffer(10000)
            if (i >= 0) {
                val n = ex.readSampleData(codec.getInputBuffer(i)!!, 0)
                if (n < 0) { codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                else { codec.queueInputBuffer(i, 0, n, ex.sampleTime, 0); ex.advance() }
            }
        }
        val o = codec.dequeueOutputBuffer(info, 10000)
        if (o >= 0) {
            val arr = ByteArray(info.size); codec.getOutputBuffer(o)!!.get(arr); out.write(arr)
            codec.releaseOutputBuffer(o, false)
            if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true
        } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
            val f = codec.outputFormat
            rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE); ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        }
    }
    codec.stop(); codec.release(); ex.release()
    val sb = ByteBuffer.wrap(out.toByteArray()).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
    val all = ShortArray(sb.remaining()); sb.get(all)
    val mono = ShortArray(all.size / ch) { i -> var s = 0; for (c in 0 until ch) s += all[i * ch + c]; (s / ch).toShort() }
    return Pcm(mono, rate)
}

fun resample(a: ShortArray, from: Int, to: Int): ShortArray {
    if (from == to || a.isEmpty()) return a
    val n = (a.size.toLong() * to / from).toInt()
    return ShortArray(n) { i ->
        val p = i.toDouble() * from / to; val k = p.toInt(); val f = p - k
        val s0 = a[minOf(k, a.size - 1)].toInt(); val s1 = a[minOf(k + 1, a.size - 1)].toInt()
        (s0 + (s1 - s0) * f).toInt().toShort()
    }
}

fun wav(a: ShortArray, rate: Int): ByteArray {
    val b = ByteBuffer.allocate(44 + a.size * 2).order(ByteOrder.LITTLE_ENDIAN)
    b.put("RIFF".toByteArray()).putInt(36 + a.size * 2).put("WAVEfmt ".toByteArray()).putInt(16)
        .putShort(1).putShort(1).putInt(rate).putInt(rate * 2).putShort(2).putShort(16)
        .put("data".toByteArray()).putInt(a.size * 2)
    for (s in a) b.putShort(s)
    return b.array()
}

fun readPdf(ctx: Context, uri: Uri): List<String> {
    PDFBoxResourceLoader.init(ctx)
    val doc = ctx.contentResolver.openInputStream(uri)!!.use { PDDocument.load(it) }
    val t = doc.use { PDFTextStripper().getText(it) }
    return t.replace("\n", " ").split(Regex("(?<=[.!?])\\s+")).map { it.trim() }.filter { it.length > 3 }
}

// Unduh model Whisper gratis dari HuggingFace (sekali saja), lalu disimpan di HP
fun downloadModel(ctx: Context, name: String, onProg: (Int) -> Unit): File {
    val f = File(ctx.filesDir, "ggml-$name.bin")
    if (f.exists() && f.length() > 1_000_000) return f
    val tmp = File(ctx.filesDir, "ggml-$name.part")
    val c = URL("https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-$name.bin").openConnection() as HttpURLConnection
    c.connectTimeout = 30000; c.readTimeout = 60000
    val total = c.contentLengthLong
    c.inputStream.use { i ->
        tmp.outputStream().use { o ->
            val buf = ByteArray(65536); var d = 0L; var n = i.read(buf)
            while (n > 0) { o.write(buf, 0, n); d += n; if (total > 0) onProg((d * 100 / total).toInt()); n = i.read(buf) }
        }
    }
    tmp.renameTo(f); return f
}

fun tsec(g: List<String>, i: Int) = g[i].toInt() * 3600 + g[i + 1].toInt() * 60 + g[i + 2].toInt() + g[i + 3].toInt() / 1000.0

// Whisper offline (whisper.cpp) per potongan 5 menit; hasil berupa segmen + timestamp
suspend fun transcribe(pcm: Pcm, model: File, onProg: (String) -> Unit): List<Seg> {
    val w = WhisperContext.createContextFromFile(model.absolutePath)
    val res = mutableListOf<Seg>()
    val rx = Regex("\\[(\\d+):(\\d+):(\\d+)\\.(\\d+) --> (\\d+):(\\d+):(\\d+)\\.(\\d+)\\]: (.*)")
    try {
        val step = pcm.rate * 300
        val chunks = (pcm.data.size + step - 1) / step
        var off = 0; var n = 0
        while (off < pcm.data.size) {
            n++; onProg("Mengubah suara jadi teks (offline)… bagian $n/$chunks")
            val part = resample(pcm.data.copyOfRange(off, minOf(off + step, pcm.data.size)), pcm.rate, 16000)
            val f = FloatArray(part.size) { part[it] / 32768f }
            val t0 = off.toDouble() / pcm.rate
            for (l in w.transcribeData(f, true).lines()) {
                val g = rx.find(l)?.groupValues ?: continue
                res += Seg(t0 + tsec(g, 1), t0 + tsec(g, 5), g[9])
            }
            off += step
        }
    } finally { w.release() }
    return res
}

fun norm(s: String) = s.lowercase().replace(Regex("[^\\p{L}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()

fun sim(a: String, b: String): Double {
    val x = norm(a); val y = norm(b)
    if (x.isEmpty() || y.isEmpty()) return 0.0
    var p = IntArray(y.length + 1) { it }
    for (i in 1..x.length) {
        val c = IntArray(y.length + 1); c[0] = i
        for (j in 1..y.length) c[j] = minOf(p[j] + 1, c[j - 1] + 1, p[j - 1] + if (x[i - 1] == y[j - 1]) 0 else 1)
        p = c
    }
    return 1.0 - p[y.length].toDouble() / maxOf(x.length, y.length)
}

// Untuk tiap kalimat naskah, cari take (1-3 segmen berurutan) yang paling mirip; seri -> ambil yang paling akhir
fun match(script: List<String>, segs: List<Seg>): List<Hit> = script.map { s ->
    var best = Hit(s, "", 0.0, 0.0, 0.0)
    for (i in segs.indices) for (w in 1..3) {
        if (i + w > segs.size) break
        val txt = segs.subList(i, i + w).joinToString(" ") { it.text }.trim()
        if (txt.length < s.length * 0.5 || txt.length > s.length * 2) continue
        val sc = sim(s, txt)
        if (sc >= best.score) best = Hit(s, txt, sc, segs[i].start, segs[i + w - 1].end)
    }
    best
}

fun slice(p: Pcm, s: Double, e: Double): ShortArray {
    val a = (maxOf(0.0, s) * p.rate).toInt().coerceIn(0, p.data.size)
    val b = (e * p.rate).toInt().coerceIn(a, p.data.size)
    return p.data.copyOfRange(a, b)
}

fun merge(p: Pcm, hits: List<Hit>, minScore: Double): ShortArray {
    val parts = hits.filter { it.score >= minScore }.map { slice(p, it.start - 0.05, it.end + 0.12) }
    val gap = (0.15 * p.rate).toInt()
    val r = ShortArray(parts.sumOf { it.size + gap })
    var pos = 0
    for (a in parts) { a.copyInto(r, pos); pos += a.size + gap }
    return r
}

var cur: AudioTrack? = null
fun play(p: Pcm, s: Double, e: Double) {
    val a = slice(p, s, e); if (a.isEmpty()) return
    cur?.release()
    val t = AudioTrack.Builder()
        .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).build())
        .setAudioFormat(AudioFormat.Builder().setSampleRate(p.rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
        .setBufferSizeInBytes(a.size * 2).setTransferMode(AudioTrack.MODE_STATIC).build()
    t.write(a, 0, a.size); t.play(); cur = t
}

fun save(ctx: Context, a: ShortArray, rate: Int) {
    val v = ContentValues().apply {
        put(MediaStore.Downloads.DISPLAY_NAME, "voiceover_fixed_${System.currentTimeMillis()}.wav")
        put(MediaStore.Downloads.MIME_TYPE, "audio/wav")
    }
    val u = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
    ctx.contentResolver.openOutputStream(u)!!.use { it.write(wav(a, rate)) }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    val scope = rememberCoroutineScope()
    var script by remember { mutableStateOf<List<String>>(emptyList()) }
    var audioUri by remember { mutableStateOf<Uri?>(null) }
    var pcm by remember { mutableStateOf<Pcm?>(null) }
    var hits by remember { mutableStateOf<List<Hit>>(emptyList()) }
    var model by remember { mutableStateOf("small") }
    var thr by remember { mutableStateOf(0.75f) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val t = thr.toDouble()

    val pdfL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) scope.launch {
            try { script = withContext(Dispatchers.IO) { readPdf(ctx, u) }; status = "Naskah: ${script.size} kalimat" }
            catch (e: Exception) { status = "Gagal baca PDF: ${e.message}" }
        }
    }
    val audL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) { audioUri = u; status = "Audio dipilih" }
    }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("VoiceOver Fix", style = MaterialTheme.typography.headlineSmall) }
        item { Button(onClick = { pdfL.launch(arrayOf("application/pdf")) }, modifier = Modifier.fillMaxWidth()) { Text("Pilih Naskah PDF") } }
        item { Button(onClick = { audL.launch(arrayOf("audio/*", "video/mp4")) }, modifier = Modifier.fillMaxWidth()) { Text("Pilih Audio Rekaman") } }
        item { OutlinedTextField(value = model, onValueChange = { model = it }, label = { Text("Model: tiny / base / small (small paling akurat)") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
        item {
            Column {
                Text("Kemiripan minimum: ${(thr * 100).toInt()}%")
                Slider(value = thr, onValueChange = { thr = it }, valueRange = 0.5f..0.95f)
            }
        }
        item {
            Button(
                enabled = !busy && script.isNotEmpty() && audioUri != null,
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    busy = true
                    scope.launch {
                        try {
                            status = "Membaca audio…"
                            val p = withContext(Dispatchers.Default) { decode(ctx, audioUri!!) }; pcm = p
                            status = "Mengunduh model (sekali saja)…"
                            val mf = withContext(Dispatchers.IO) { downloadModel(ctx, model.trim()) { status = "Mengunduh model… $it%" } }
                            val segs = withContext(Dispatchers.Default) { transcribe(p, mf) { status = it } }
                            status = "Mencocokkan dengan naskah…"
                            hits = withContext(Dispatchers.Default) { match(script, segs) }
                            status = "Selesai. Cek hasil di bawah."
                        } catch (e: Exception) { status = "Error: ${e.message}" } finally { busy = false }
                    }
                }
            ) { Text("Proses") }
        }
        item { Text(status) }
        itemsIndexed(hits) { _, h ->
            val c = if (h.score >= t) Color(0xFFC8E6C9) else if (h.score >= t - 0.2) Color(0xFFFFF59D) else Color(0xFFFFCDD2)
            Row(Modifier.fillMaxWidth().background(c).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(h.script, style = MaterialTheme.typography.bodyMedium)
                    if (h.heard.isNotEmpty() && h.score < 0.98) Text("Terdengar: ${h.heard}", style = MaterialTheme.typography.bodySmall)
                    Text("${(h.score * 100).toInt()}%", style = MaterialTheme.typography.labelSmall)
                }
                TextButton(onClick = { pcm?.let { play(it, h.start - 0.05, h.end + 0.12) } }) { Text("▶") }
            }
        }
        item {
            if (hits.isNotEmpty()) Button(modifier = Modifier.fillMaxWidth(), onClick = {
                scope.launch {
                    try {
                        val p = pcm!!
                        val a = withContext(Dispatchers.Default) { merge(p, hits, t - 0.2) }
                        withContext(Dispatchers.IO) { save(ctx, a, p.rate) }
                        status = "Tersimpan di folder Download (kalimat merah dilewati)"
                    } catch (e: Exception) { status = "Error: ${e.message}" }
                }
            }) { Text("Gabung & Simpan") }
        }
    }
}
