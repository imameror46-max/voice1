pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement { repositories { google(); mavenCentral() } }
rootProject.name = "VoiceOverFix"
include(":app")
include(":lib")
project(":lib").projectDir = file("whisper.cpp/examples/whisper.android/lib")
